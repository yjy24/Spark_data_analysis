# -*- coding: utf-8 -*-
"""
Created on Mon Dec 16 11:36:04 2019

@author: JaneYu
"""

from pyspark import SparkConf, SparkContext
import collections

conf = SparkConf().setMaster("local").setAppName("RatingsHistogram")
sc = SparkContext(conf = conf)

lines = sc.textFile("file:///Learning/lessons/spark_code_resource/ml-100k/u.data")

rating = lines.map(lambda x: x.split()[2])
results = rating.countByValue()
resultsNum = rating.count()
print(" Total movie num: %i" %resultsNum)
sortedResults = collections.OrderedDict(sorted(results.items()))
for key, value in sortedResults.items():
    print(" score %s. movie num: %i" %(key,value))
'''
 score 1. movie num: 6110
 score 2. movie num: 11370
 score 3. movie num: 27145
 score 4. movie num: 34174
 score 5. movie num: 21201
 '''




'''ratings = lines.map(lambda x: x.split()[2])
result = ratings.countByValue()

sortedResults = collections.OrderedDict(sorted(result.items()))
for key, value in sortedResults.items():
    print("%s %i" % (key, value))'''